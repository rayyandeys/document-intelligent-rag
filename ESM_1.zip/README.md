Article: Evaluating Chunking Strategies for Retrieval Augmented Generation over Scientific Documents
Journal: SN Computer Science
Author and corresponding author: Syed Mohammed Rayyan
Affiliation: SRM Institute of Science and Technology, Kattankulathur, Tamil Nadu, India
Email: smrayyan15@gmail.com
Online Resource 1: Python source and saved retrieval and truncation evidence.

# Document retrieval experiment evidence

This package contains the 26 Python source files supplied by the author on 13 September 2026, together with the two completed retrieval runs and the truncation analysis. Top-level Python scripts from the uploaded archive are restored under experiments/; src/ paths are preserved. Byte content is unchanged. Cached bytecode is excluded.

All 26 source files match the prepared project code after normalizing Windows CRLF to LF. See code_verification.json for exact file hashes and the original archive hash. The source snapshot was obtained after execution; no claim of contemporaneous source hashing or an independent dense-inference replication is made. Original run manifests, rankings and summary files are unchanged.

Benchmark corpora and model weights are not bundled. The download script retrieves BEIR data. Run manifests record dataset hashes, package versions, the model revision and the 256-token limit. Review those versions before setting up an environment. The recorded base Git commit alone is not the complete source identity because the working tree was dirty.

From the package root, python -m experiments.run_journal_suite performs a new retrieval suite and may take substantial time and require network access. Existing saved results do not need to be rerun for inspection. python -m experiments.analyze_truncation performs the length analysis with an available cached tokenizer and the requisite benchmark files. This archive contains research code/evidence, not the complete web application.
